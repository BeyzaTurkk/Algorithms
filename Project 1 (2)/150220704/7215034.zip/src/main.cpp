#include "tweet.h"

int main() 
{
    std::vector<Tweet> tweets = readTweetsFromFile("/workspaces/BLG335E_HW1/Code/data/permutations/tweets.csv"); 
    std::vector<Tweet> tweetsNS = readTweetsFromFile("/workspaces/BLG335E_HW1/Code/data/permutations/tweetsNS.csv"); 
    std::vector<Tweet> tweetsSA = readTweetsFromFile("/workspaces/BLG335E_HW1/Code/data/permutations/tweetsSA.csv"); 
    std::vector<Tweet> tweetsSD = readTweetsFromFile("/workspaces/BLG335E_HW1/Code/data/permutations/tweetsSD.csv"); 
    
    std::vector<Tweet> tweets50k_1 = readTweetsFromFile("/workspaces/BLG335E_HW1/Code/data/sizes/tweets50K.csv"); 
    std::vector<Tweet> tweets30k_1 = readTweetsFromFile("/workspaces/BLG335E_HW1/Code/data/sizes/tweets30K.csv"); 
    std::vector<Tweet> tweets20k_1 = readTweetsFromFile("/workspaces/BLG335E_HW1/Code/data/sizes/tweets20K.csv"); 
    std::vector<Tweet> tweets10k_1 = readTweetsFromFile("/workspaces/BLG335E_HW1/Code/data/sizes/tweets10K.csv"); 
    std::vector<Tweet> tweets5k_1 = readTweetsFromFile("/workspaces/BLG335E_HW1/Code/data/sizes/tweets5K.csv"); 

   

    clock_t t_tweets=clock();
    mergeSort(tweets,0,tweets.size()-1,"retweetCount",1);
    clock_t t_tweets_d=clock()-t_tweets;
    std::cout << "Duration of mergeSort for tweets: " << (float)t_tweets_d / CLOCKS_PER_SEC << " seconds"<<"\n";


     clock_t t_tweetsSA=clock();
    mergeSort(tweetsSA,0,tweetsNS.size()-1,"retweetCount",1);
    clock_t t_tweetsSA_d=clock()-t_tweetsSA;
    std::cout << "Duration of mergeSort for tweetsSA: " << (float)t_tweetsSA_d / CLOCKS_PER_SEC << " seconds"<<"\n";
    
    clock_t t_tweetsSD=clock();
    mergeSort(tweetsSD,0,tweetsSD.size()-1,"retweetCount",1);
    clock_t t_tweetsSD_d=clock()-t_tweetsSD;
    std::cout << "Duration of mergeSort for tweetsSD: " << (float)t_tweetsSD_d / CLOCKS_PER_SEC << " seconds"<<"\n";
    
    
    clock_t t_tweetsNS=clock();
    mergeSort(tweetsNS,0,tweetsNS.size()-1,"retweetCount",1);
    clock_t t_tweetsNS_d=clock()-t_tweetsNS;
    std::cout << "Duration of mergeSort for tweetsNS: " << (float)t_tweetsNS_d / CLOCKS_PER_SEC << " seconds"<<"\n";
    
   
    
    clock_t t_tweets5=clock();
    mergeSort(tweets5k_1,0,tweets5k_1.size()-1,"retweetCount",1);
    clock_t t_tweets5_d=clock()-t_tweets5;
    std::cout << "Duration of mergeSort for tweets5: " << (float)t_tweets5_d / CLOCKS_PER_SEC << " seconds"<<"\n";

    clock_t t_tweets30=clock();
    mergeSort(tweets30k_1,0,tweets30k_1.size()-1,"retweetCount",1);
    clock_t t_tweets30_d=clock()-t_tweets30;
    std::cout << "Duration of mergeSort for tweets30: " << (float)t_tweets30_d / CLOCKS_PER_SEC << " seconds"<<"\n";

    clock_t t_tweets20=clock();
    mergeSort(tweets20k_1,0,tweets20k_1.size()-1,"retweetCount",1);
    clock_t t_tweets20_d=clock()-t_tweets20;
    std::cout << "Duration of mergeSort for tweets20: " << (float)t_tweets20_d / CLOCKS_PER_SEC << " seconds"<<"\n";
    
    clock_t t_tweets10=clock();
    mergeSort(tweets10k_1,0,tweets10k_1.size()-1,"retweetCount",1);
    clock_t t_tweets10_d=clock()-t_tweets10;
    std::cout << "Duration of mergeSort for tweets10: " << (float)t_tweets10_d / CLOCKS_PER_SEC << " seconds"<<"\n";
    
    clock_t t_tweets50=clock();
    mergeSort(tweets50k_1,0,tweets50k_1.size()-1,"retweetCount",1);
    clock_t t_tweets50_d=clock()-t_tweets50;
    std::cout << "Duration of mergeSort for tweets50: " << (float)t_tweets50_d / CLOCKS_PER_SEC << " seconds"<<"\n";
    

}