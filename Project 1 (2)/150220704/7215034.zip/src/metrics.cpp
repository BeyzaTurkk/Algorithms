#include "tweet.h"

int binarySearch(const std::vector<Tweet>& tweets, long long key, const std::string& sortBy)
{
    int low=0;
    int high=tweets.size()-1;

    while(low<=high){
        int middle=low+ (high-low)/2;
        
        long long value;
        if(sortBy=="tweetID"){
            value=tweets[middle].tweetID;        
        }else if(sortBy=="retweetCount"){
           value=tweets[middle].retweetCount; 
        }else if(sortBy=="favoriteCount"){
            value=tweets[middle].favoriteCount; 
        }else return -1;

        if(value<key){
            low=middle+1;
        }else if(value>key){
            high=middle-1;
        }else return middle;
    
}
        return -1;
}

int countAboveThreshold(const std::vector<Tweet>& tweets, const std::string& metric, int threshold) 
{   
    int count=0;
    for(const auto&tweet: tweets){
        if(metric=="favoriteCount" && tweet.favoriteCount> threshold)
            count++;
        else if(metric=="retweetCount"&& tweet.retweetCount >threshold)
            count++;
        }
        return count;
}
