#include "tweet.h"

void bubbleSort(std::vector<Tweet> &tweets, const std::string &sortBy, bool ascending)
{
    int length = tweets.size();
    int ascco;
    if (ascending == true)
    {
        ascco = 1;
    }
    else
    {
        ascco = -1;
    }

    if (sortBy == "tweetID")
    {
        for (int i = 1; i < tweets.size(); i++)
        {
            bool swapped = false;

            for (int j = 0; j < length - 1; j++)
            {
                if (tweets[j].tweetID * ascco > tweets[j + 1].tweetID * ascco)
                {
                    Tweet temp = tweets[j];
                    tweets[j] = tweets[j + 1];
                    tweets[j + 1] = temp;
                    swapped = true;
                }
            }
            if (!swapped)
                break;
            length--;
        }
    }
    else if (sortBy == "favoriteCount")
    {
        for (int i = 1; i < tweets.size(); i++)
        {
            bool swapped = false;

            for (int j = 0; j < length - 1; j++)
            {
                if (tweets[j].favoriteCount * ascco > tweets[j + 1].favoriteCount * ascco)
                {
                    Tweet temp = tweets[j];
                    tweets[j] = tweets[j + 1];
                    tweets[j + 1] = temp;
                    swapped = true;
                }
            }
            if (!swapped)
                break;
            length--;
        }
    }
    else
    {
        for (int i = 1; i < tweets.size(); i++)
        {
            bool swapped = false;

            for (int j = 0; j < length - 1; j++)
            {
                if (tweets[j].retweetCount * ascco > tweets[j + 1].retweetCount * ascco)
                {
                    Tweet temp = tweets[j];
                    tweets[j] = tweets[j + 1];
                    tweets[j + 1] = temp;
                    swapped = true;
                }
            }
            if (!swapped)
                break;
            length--;
        }
    }
}

void insertionSort(std::vector<Tweet> &tweets, const std::string &sortBy, bool ascending)
{
    int ascco;
    if (ascending == true)
    {
        ascco = 1;
    }
    else
    {
        ascco = -1;
    }

    if (sortBy == "tweetID")
    {
        for (int i = 0; i < tweets.size() - 1; i++)
        {

            for (int j = i + 1; j > 0; j--)
            {
                if (tweets[j].tweetID * ascco < tweets[j - 1].tweetID * ascco)
                {
                    Tweet temp = tweets[j];
                    tweets[j] = tweets[j - 1];
                    tweets[j - 1] = temp;
                }
                else
                    break;
            }
        }
    }
    else if (sortBy == "favoriteCount")
    {
        for (int i = 0; i < tweets.size() - 1; i++)
        {

            for (int j = i + 1; j > 0; j--)
            {
                if (tweets[j].favoriteCount * ascco < tweets[j - 1].favoriteCount * ascco)
                {
                    Tweet temp = tweets[j];
                    tweets[j] = tweets[j - 1];
                    tweets[j - 1] = temp;
                }
                else
                    break;
            }
        }
    }
    else
    {
        for (int i = 0; i < tweets.size() - 1; i++)
        {

            for (int j = i + 1; j > 0; j--)
            {
                if (tweets[j].retweetCount * ascco < tweets[j - 1].retweetCount * ascco)
                {
                    Tweet temp = tweets[j];
                    tweets[j] = tweets[j - 1];
                    tweets[j - 1] = temp;
                }
                else
                    break;
            }
        }
    }
}

void merge(std::vector<Tweet> &tweets, int left, int mid, int right, const std::string &sortBy, bool ascending)
{
    std::vector<Tweet> rightArray;
    std::vector<Tweet> leftArray;
    int r = 0;
    int l = 0;
    int ascco;
    if (ascending == true)
    {
        ascco = 1;
    }
    else
    {
        ascco = -1;
    }

    for (int i = 0; i < right - mid - 1 + 1; i++)
    {
        rightArray.push_back(tweets[i + mid + 1]);
    }
    for (int i = 0; i < mid - left + 1; i++)
    {
        leftArray.push_back(tweets[i + left]);
    }

    if (sortBy == "tweetID")
    {
        for (int i = 0; i < leftArray.size() + rightArray.size(); i++)
            if (l < leftArray.size() && r < rightArray.size())
            {

                if (rightArray[r].tweetID * ascco <= leftArray[l].tweetID * ascco)
                {
                    tweets[i + left] = rightArray[r];
                    r++;
                }
                else
                {
                    tweets[i + left] = leftArray[l];
                    l++;
                }
            }
            else if (l >= leftArray.size())
            {

                {
                    tweets[i + left] = rightArray[r];
                    r++;
                }
            }
            else if (r >= rightArray.size())
            {

                tweets[i + left] = leftArray[l];
                l++;
            }
    }
    else if (sortBy == "favoriteCount")
    {
        for (int i = 0; i < leftArray.size() + rightArray.size(); i++)
            if (l < leftArray.size() && r < rightArray.size())
            {

                if (rightArray[r].favoriteCount * ascco <= leftArray[l].favoriteCount * ascco)
                {
                    tweets[i + left] = rightArray[r];
                    r++;
                }
                else
                {
                    tweets[i + left] = leftArray[l];
                    l++;
                }
            }
            else if (l >= leftArray.size())
            {

                tweets[i + left] = rightArray[r];
                r++;
            }
            else if (r >= rightArray.size())
            {

                tweets[i + left] = leftArray[l];
                l++;
            }
    }
    else if (sortBy == "retweetCount")
    {
        for (int i = 0; i < leftArray.size() + rightArray.size(); i++)
            if (l < leftArray.size() && r < rightArray.size())
            {

                if (rightArray[r].retweetCount * ascco <= leftArray[l].retweetCount * ascco)
                {
                    tweets[i + left] = rightArray[r];
                    r++;
                }
                else
                {
                    tweets[i + left] = leftArray[l];
                    l++;
                }
            }
            else if (l >= leftArray.size())
            {

                tweets[i + left] = rightArray[r];
                r++;
            }
            else if (r >= rightArray.size())
            {

                tweets[i + left] = leftArray[l];
                l++;
            }
    }
}

void mergeSort(std::vector<Tweet> &tweets, int left, int right, const std::string &sortBy, bool ascending)
{
    if (left == right)
    {
        return;
    }
    mergeSort(tweets, left, (right + left) / 2, sortBy, ascending);
    mergeSort(tweets, (right + left) / 2 + 1, right, sortBy, ascending);
    merge(tweets, left, (left + right) / 2, right, sortBy, ascending);
}