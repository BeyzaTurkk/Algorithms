#include "tweet.h"
#include <fstream>
#include <sstream>
#include <vector>

std::vector<Tweet> readTweetsFromFile(const std::string& filename) 
{
    std::vector<Tweet> tweets;
    std:: ifstream file(filename);
    std::string line;

    if(!file.is_open()){
        std::cerr<<"File:"<< filename <<"could not opened." <<std::endl;
        return tweets;
    }
    std::getline(file,line);

    while(std::getline(file,line)){
        std::stringstream ss(line);
        Tweet tweet;
        std:: string part;

        std::getline(ss,part, ',');
        tweet.tweetID=std::stoll(part);

        std::getline(ss,part, ',');
        tweet.retweetCount=std::stoi(part);

        std::getline(ss,part, ',');
        tweet.favoriteCount=std::stoi(part);

        tweets.push_back(tweet);

    }
    file.close();
    return tweets;
}

void writeTweetsToFile(const std::string& filename, const std::vector<Tweet>& tweets) 
{   std::ofstream file(filename);

    if(!file.is_open()){
        std::cerr<<"File:"<< filename <<"could not opened." <<std::endl;
        return;
    }
    file<< " tweetID,retweet_count,favorite_count "<<std::endl;


    for(const auto&tweet : tweets){
        file<< tweet.tweetID<< ","<<tweet.retweetCount <<","<< tweet.favoriteCount<<"\n";
    }

    file.close();
}