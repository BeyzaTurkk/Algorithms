
#include "methods.h"
void newRarity(std::vector<Item> &items, int ageWindow) // Looking for only the same origin
{
  int age_max = getMax(items, "age");
  int count_total, count_similar;
  double prob, rarity;

  for (int i = 0; i < items.size(); i++)
  {
    count_similar = 0;
    count_total = 0;

    for (int j = i + 1; j < items.size(); j++)
    {
      if (items[j].age > items[i].age + ageWindow)
      {
        break;
      }
      count_total++;
      if (items[j].origin == items[i].origin)
      {
        count_similar++;
      }
    }

    for (int j = i - 1; j >= 0; j--)
    {
      if (items[j].age < items[i].age - ageWindow)
      {
        break;
      }
      count_total++;
      if (items[j].origin == items[i].origin || items[j].type == items[i].type)
      {
        count_similar++;
      }
    }

    prob = count_total == 0 ? 0 : count_similar / count_total;
    rarity = (1 - prob) * (1 + (items[i].age / age_max));
    items[i].rarityScore = rarity;
  }
}

int main()
{
  std::vector<Item> items = readItemsFromFile("data/items_l.csv");
  std::vector<Item> sorted = countingSort(items, "age", true);
  writeItemsToFile("data/items_l_sorted.csv", sorted);
  calculateRarityScores(sorted, 50);
  writeItemsToFile("data/items_l_rarity.csv", sorted);
  sorted = heapSortByRarity(sorted, true);
  writeItemsToFile("data/items_l_rarity_sorted.csv", sorted);

  return 0;
}