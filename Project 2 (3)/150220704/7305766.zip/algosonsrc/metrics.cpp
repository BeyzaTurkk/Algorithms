#include "methods.h"

int getMax(std::vector<Item> &items, const std::string &attribute)
{
    int max = 0;
    if (attribute == "age")
    {
        for (int i = 0; i < items.size(); i++)
        {
            if (items[i].age > max)
            {
                max = items[i].age;
            }
        }
    }
    if (attribute == "rarityScore")
    {
        for (int i = 0; i < items.size(); i++)
        {
            if (items[i].rarityScore > max)
            {
                max = items[i].rarityScore;
            }
        }
    }
    return max;
}

// min = age - ageWindow
// max = age + ageWindow
// rarityScore = (1 - probability) * (1 + item.age/ageMax)
void calculateRarityScores(std::vector<Item> &items, int ageWindow)
{
    int max_age = getMax(items,"age");
    double count_total, count_similar;
    double probability, rarity,age;
    for (int i = 0; i < items.size(); i++)
    {
        age=items[i].age;
        count_total=0; 
        count_similar = 0;
        for (int j = i ; j < items.size(); j++)
        {
            if (items[j].age <= items[i].age + ageWindow)
            {
                count_total++;
                if (items[j].origin == items[i].origin && items[j].type == items[i].type)
                {
                    count_similar++;
                }
            }
            else
            {
                break;
            }
        }
     
        for (int j = i ; j >= 0; j--)
        {
            if (items[j].age >= items[i].age - ageWindow)
            {
                count_total++;
                if (items[j].origin == items[i].origin && items[j].type == items[i].type)
                {
                    count_similar++;
                }
            }
            else
            {
                break;
            }
        }
    count_total=count_total-1;
    count_similar=count_similar-1;
    if(count_total==0){
        probability=0;
    }else{
        probability=count_similar/count_total;
    }
    rarity=(1-probability)*(1+(age/ max_age));
    items[i].rarityScore=rarity;
    }


}
