#include "methods.h"

std::vector<Item> countingSort(std::vector<Item> &items, const std::string &attribute, bool ascending)
{
    std::vector<int> index_vector(getMax(items, attribute) + 1, 0);
    for (int i = 0; i < items.size(); i++)
    {
        index_vector[items[i].age]++;
    }
    for (int i = 0; i < index_vector.size() - 1; i++)
    {
        index_vector[i + 1] = index_vector[i] + index_vector[i + 1];
    }

    std::vector<Item> sorted_vector(items.size());
    for (int i = items.size()-1; i >= 0; i--)
    { if(ascending==true)
    {
        sorted_vector[index_vector[items[i].age] - 1] = items[i];
        index_vector[items[i].age]--;

    }else{
        sorted_vector[items.size()-index_vector[items[i].age]]=items[i];
        index_vector[items[i].age]--;
    }
    }

    return sorted_vector;
}

// Function to heapify a subtree rooted with node i in the array of items
void heapify(std::vector<Item> &items, int n, int i, bool descending)
{
    int node = i; 
    int left = 2 * i + 1;
    int right = 2 * i + 2;
    int coeff = descending ? -1 : 1;

    // Compare with left child
    if (left < n && items[node].rarityScore * coeff < items[left].rarityScore * coeff) {
        node = left;
    }

    // Compare with right child
    if (right < n && items[node].rarityScore * coeff < items[right].rarityScore * coeff) {
        node = right;
    }

   
    if (node != i) {
        Item temp = items[i];
        items[i] = items[node];
        items[node] = temp;

        heapify(items, n, node, descending);
    }
}



// Function to perform heap sort on rarityScore scores of items
std::vector<Item> heapSortByRarity(std::vector<Item> &items, bool descending)
{
    int size = items.size();
    int parent = (size / 2) - 1;
    for (int i = parent; i >= 0; i--)
    {
        heapify(items, size, i, descending);
    }
    for (int i = size - 1; i > 0; i--)
    {
        Item temp = items[i];
        items[i] = items[0];
        items[0] = temp;
        heapify(items, i, 0, descending);
    }
    return items;
}
