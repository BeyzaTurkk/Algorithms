#include "methods.h"

std::vector<Item> readItemsFromFile(const std::string& filename) 
{
     std::vector<Item> Items;
    std:: ifstream file(filename);
    std::string line;

    if(!file.is_open()){
        std::cerr<<"File:"<< filename <<"could not opened." <<std::endl;
        return Items;
    }
    std::getline(file,line);

    while(std::getline(file,line)){
        std::stringstream ss(line);
        Item Item;
        std:: string part, age,type, origin, rare;

        std::getline(ss,part, ',');
        Item.age=std::stoi(part);

        std::getline(ss,part, ',');
        Item.type=std::stoi(part);

        std::getline(ss,part,',');
        Item.origin=std::stoi(part);

        std::getline(ss,part, '\n');
        Item.rarityScore=std::stod(part);

        Items.push_back(Item);

    }
    file.close();
    return Items;

}

void writeItemsToFile(const std::string& filename, const std::vector<Item>& items) 
{
  std::ofstream file(filename);

    if(!file.is_open()){
        std::cerr<<"File:"<< filename <<"could not opened." <<std::endl;
        return;
    }
    file<< " age, type, origin, rarityScore"<<std::endl;


    for(const auto&item : items){
        file<< item.age<< ","<<item.type <<","<< item.origin<<","<<item.rarityScore<<"\n";
    }
}
