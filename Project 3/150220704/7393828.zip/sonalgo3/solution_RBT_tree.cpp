#include <iostream>
#include <stdlib.h>
#include <iomanip>
#include <string.h>
#include <string>
#include <fstream>
#include <vector>
#include <algorithm>
#include <stack>
#include <iomanip>
#include <chrono>
#include <random>

using namespace std;
using namespace std::chrono;

/////////////////// Player ///////////////////
class publisher
{
public:
    string name;
    float na_sales;
    float eu_sales;
    float others_sales;
};

/////////////////// Node ///////////////////
class Node
{
public:
    publisher key;
    int color; // "Red"=1 or "Black"=0
    Node *parent, *left, *right;

    Node(publisher);
    ~Node();
    int get_color();
    void set_color(int);
};

/////////////////// RB-Tree ///////////////////
class RB_tree
{
private:
    Node *root;

public:
    publisher *best_seller[3];
    stack<string> tree_deep_stack;

    Node *get_root();

    Node *RB_insert(Node *root, Node *ptr);
    void insertValue(vector<string>);
    void taskF(vector<string>);
    void RB_left_rotate(Node *);
    void RB_right_rotate(Node *);
    void RB_insert_fixup(Node *);
    void preorder();
    void find_best_seller();

    RB_tree();
    ~RB_tree();
};

void print_best_sellers(int year, publisher *temp_publisher[3])
{
    cout.precision(5);
    cout << "End of the " + to_string(year) + " Year" << endl;
    cout << "Best seller in North America: " + temp_publisher[0]->name + " - " << temp_publisher[0]->na_sales << " million" << endl;
    cout << "Best seller in Europe: " + temp_publisher[1]->name + " - " << temp_publisher[1]->eu_sales << " million" << endl;
    cout << "Best seller rest of the World: " + temp_publisher[2]->name + " - " << temp_publisher[2]->others_sales << " million" << endl;
}

RB_tree generate_RBT_tree_from_csv(string file_name)
{
   
	RB_tree temp_RBtree;
	ifstream file(file_name);
	string line;
	getline(file, line);

	int lower=1990;
	int upper=lower+10;
	while (getline(file, line))
	{
		vector<string> v;
		string name, platform, publisher_name;
		string year_of_release;
		string na_sales, eu_sales, others_sales;
		int start = 0;
		int end = line.find(',');

		name = line.substr(start, end - start);
		start = end + 1;
		v.push_back(name);

		end = line.find(',', start);
		platform = line.substr(start, end - start);
		start = end + 1;
		v.push_back(platform);



		end = line.find(',', start);
		year_of_release = line.substr(start, end - start);
		start = end + 1;
		v.push_back(year_of_release);
		

		end = line.find(',', start);
		publisher_name = line.substr(start, end - start);
		start = end + 1;
		v.push_back(publisher_name);

		end = line.find(',', start);
		na_sales = line.substr(start, end - start);
		start = end + 1;
		v.push_back(na_sales);

		end = line.find(',', start);
		eu_sales = line.substr(start, end - start);
		start = end + 1;
		v.push_back(eu_sales);
		end = line.find('\r', start);
		others_sales = line.substr(start, end - start);
		v.push_back(others_sales);

		if(stoi(year_of_release)>lower && stoi(year_of_release)<upper){
			temp_RBtree.find_best_seller();
			print_best_sellers(lower, temp_RBtree.best_seller );
			lower=upper;
			upper+=10;
		}

		temp_RBtree.insertValue(v);
	}
	temp_RBtree.find_best_seller();
	print_best_sellers(lower, temp_RBtree.best_seller );	
	return temp_RBtree;
}
Node *tree_search(Node *root, string name)
{
	if (root == nullptr)
		return nullptr;
	Node *temp = root;

	if (temp->key.name == name)
	{
		return temp;
	}
	else if (temp->key.name < name)
	{
		temp = tree_search(temp->right, name);
	}
	else
	{
		temp = tree_search(temp->left, name);
	}
	return temp;
}


void merge(std::vector<vector<string> > &tweets, int left, int mid, int right, const std::string &sortBy, bool ascending)
{
	int coeff;
	int temp_left = left;
	int left_end = mid;
	int right_end = right;
	int right_start = mid + 1;
	std::vector<vector<string> > temp;

	for (int i = 0; i < right - left + 1; i++)
	{
		if (temp_left <= mid && right_start <= right)
		{
			if (tweets[temp_left][0] < tweets[right_start][0])
			{
				temp.push_back(tweets[temp_left]);
				temp_left++;
			}
			else
			{
				temp.push_back(tweets[right_start]);
				right_start++;
			}
		}
		else
		{
			if (temp_left > mid)
			{

				temp.push_back(tweets[right_start]);
				right_start++;
			}
			else if (right_start > right)
			{

				temp.push_back(tweets[temp_left]);
				temp_left++;
			}
		}
	}

	for (int i = 0; i < temp.size(); i++)
	{
		tweets[left + i] = temp[i];
	}
}

void mergeSort(std::vector<vector<string> > &tweets, int left, int right, const std::string &sortBy, bool ascending)
{
	if (left == right)
	{
		return;
	}
	int middy = (left + right) / 2;
	mergeSort(tweets, left, middy, sortBy, ascending);
	mergeSort(tweets, middy + 1, right, sortBy, ascending);
	merge(tweets, left, middy, right, sortBy, ascending);
}
RB_tree sort(string arg)
{
	RB_tree tree;
	ifstream file(arg);
	string line;
	vector<vector<string> > myvec;
	getline(file, line);
	while (getline(file, line))
	{
		vector<string> v;
		string name, platform, publisher_name;
		string year_of_release;
		string na_sales, eu_sales, others_sales;
		int start = 0;
		int end = line.find(',');

		name = line.substr(start, end - start);
		start = end + 1;
		v.push_back(name);

		end = line.find(',', start);
		platform = line.substr(start, end - start);
		start = end + 1;
		v.push_back(platform);

		end = line.find(',', start);
		year_of_release = line.substr(start, end - start);
		start = end + 1;
		v.push_back(year_of_release);

		end = line.find(',', start);
		publisher_name = line.substr(start, end - start);
		start = end + 1;
		v.push_back(publisher_name);

		end = line.find(',', start);
		na_sales = line.substr(start, end - start);
		start = end + 1;
		v.push_back(na_sales);

		end = line.find(',', start);
		eu_sales = line.substr(start, end - start);
		start = end + 1;
		v.push_back(eu_sales);
		end = line.find('\r', start);
		others_sales = line.substr(start, end - start);
		v.push_back(others_sales);
		myvec.push_back(v);
	}
	mergeSort(myvec, 0, myvec.size() - 1, "", 1);

	for (int i = 0; i < myvec.size(); i++)
	{
		tree.taskF(myvec[i]);
	}
	vector<string> keys;
	keys.push_back("The Great Escape");
	keys.push_back("Archer Maclean's 3D Pool");
	keys.push_back("SimCity 4");
	keys.push_back("NFL Blitz Pro");
	keys.push_back("Netsu Chu! Pro Yakyuu 2003");

	float total = 0;
	Node *temp;
	for (int i = 0; i < 50; i++)
	{
		int j = rand() % 5;
		clock_t begin = clock();
		temp = tree_search(tree.get_root(), keys[j]);
		clock_t stop = clock() - begin;
		total = total + (float)stop / CLOCKS_PER_SEC;
	}
	cout << "Result for 50 random searches sorted:" << total / 50 << '\n';

	return tree;
}
void printTimes(RB_tree& tree){
	vector<string> keys;
	keys.push_back("Ubisoft");
	keys.push_back("Nintendo");
	keys.push_back("Acclaim Entertainment");
	keys.push_back("Electronic Arts");
	keys.push_back("Konami Digital Entertainment");

	float total = 0;
	Node *temp;
	for (int i = 0; i < 50; i++)
	{
		int j = rand() % 5;
		clock_t begin = clock();
		temp = tree_search(tree.get_root(), keys[j]);
		clock_t stop = clock() - begin;
		total = total + (float)stop / CLOCKS_PER_SEC;
	}
	cout << "Result for 50 random searches unsorted:" << total / 50 << '\n';

}

////////////////////////////////////////////
//----------------- MAIN -----------------//
////////////////////////////////////////////
int main(int argc, char *argv[])
{

    string fname = argv[1];
    clock_t start=clock();
    RB_tree RBtree = generate_RBT_tree_from_csv(fname);
	clock_t stop=clock()-start;
	cout<<"Red Black Tree insertion time:"<<(float)stop/CLOCKS_PER_SEC<<'\n';
    RBtree.preorder();
    printTimes(RBtree);
    sort(fname);
    // Fill this function.

    return EXIT_SUCCESS;
}
/////////////////// Node ///////////////////

Node::Node(publisher key)
{
    this->key = key;
    this->color = 1; // "RED";
    this->parent = NULL;
    this->left = NULL;
    this->right = NULL;
}

/////////////////// RB-Tree ///////////////////
Node *RB_tree::get_root()
{

    // Fill this function.

    return this->root;
}

Node *RB_tree::RB_insert(Node *root, Node *ptr)
{

    if (this->root == nullptr)
    {

        this->root = ptr;
        this->root->parent = nullptr;
        return this->root;
    }
    else
    {
        if (root==nullptr)
		{
			return ptr;
		}
        if (ptr->key.name < root->key.name)
        {
            if (root->left == nullptr)
            {
                root->left = ptr;
                ptr->parent = root;
            }
            else
            {
                root->left = RB_insert(root->left, ptr);
            }
        }
        else if (ptr->key.name > root->key.name)
        {
            if (root->right == nullptr)
            {
                root->right = ptr;
                ptr->parent = root;
            }
            else
            {
                root->right = RB_insert(root->right, ptr);
            }
        }
        else
        {

            root->key.eu_sales += ptr->key.eu_sales;
            root->key.na_sales += ptr->key.na_sales;
            root->key.others_sales += ptr->key.others_sales;
        }
    }
    return root;
}

void RB_tree::insertValue(vector<string> n)
{

    publisher pub;
    pub.name = n[3];
    pub.na_sales = stof(n[4]);
    pub.eu_sales = stof(n[5]);
    pub.others_sales = stof(n[6]);

    Node *newNode = new Node(pub);
    RB_insert(this->root, newNode);
    RB_insert_fixup(newNode);
}
void RB_tree::taskF(vector<string> n)
{

    publisher pub;
    pub.name = n[0];
    pub.na_sales = stof(n[4]);
    pub.eu_sales = stof(n[5]);
    pub.others_sales = stof(n[6]);

    Node *newNode = new Node(pub);
    RB_insert(this->root, newNode);
    RB_insert_fixup(newNode);
}
void RB_tree::RB_left_rotate(Node *ptr)
{

    Node *child = ptr->right;
    ptr->right = child->left;
    if (ptr->right != nullptr)
    {
        ptr->right->parent = ptr;
    }
    child->parent = ptr->parent;
    if (ptr->parent == nullptr)
    {
        this->root = child;
    }
    else if (ptr == ptr->parent->left)
    {

        ptr->parent->left = child;
    }
    else
    {
        ptr->parent->right = child;
    }
    child->left = ptr;
    ptr->parent = child;
}

void RB_tree::RB_right_rotate(Node *ptr)
{
    Node *child = ptr->left;
    ptr->left = child->right;
    if (ptr->left != nullptr)
    {
        ptr->left->parent = ptr;
    }
    child->parent = ptr->parent;
    if (ptr->parent == nullptr)
    {

        root = child;
    }
    else if (ptr == ptr->parent->left)
    {
        ptr->parent->left = child;
    }
    else
    {
        ptr->parent->right = child;
    }
    child->right = ptr;
    ptr->parent = child;
}

void RB_tree::RB_insert_fixup(Node *ptr)
{

    while (ptr->parent && ptr->parent->color == 1)
    {
        if (ptr->parent == ptr->parent->parent->left)
        {
            Node *uncle = ptr->parent->parent->right;

            // Case 1
            if (uncle && uncle->color == 1)
            {
                ptr->parent->color = 0;
                uncle->color = 0;
                ptr->parent->parent->color = 1;
                ptr = ptr->parent->parent;
            }
            else
            {
                // Case 2
                if (ptr == ptr->parent->right)
                {
                    ptr = ptr->parent;
                    RB_left_rotate(ptr);
                }
                // Case 3
                ptr->parent->color = 0;
                ptr->parent->parent->color = 1;
                RB_right_rotate(ptr->parent->parent);
            }
        }
        else
        {
            Node *uncle = ptr->parent->parent->left;

            // Case 1
            if (uncle && uncle->color == 1)
            {
                ptr->parent->color = 0;
                uncle->color = 0;
                ptr->parent->parent->color = 1;
                ptr = ptr->parent->parent;
            }
            else
            {
                // Case 2
                if (ptr == ptr->parent->left)
                {
                    ptr = ptr->parent;
                    RB_right_rotate(ptr);
                }
                // Case 3
                ptr->parent->color = 0;
                ptr->parent->parent->color = 1;
                RB_left_rotate(ptr->parent->parent);
            }
        }
    }
    this->root->color = 0;
}

void RB_tree::preorder()
{
    if (this->root == nullptr)
    {
        return;
    }

    stack<pair<Node *,int> > s;
    s.push(make_pair(this->root, 0));
    
    
    while (!s.empty())
    {
        Node* temp = s.top().first;
        int depth = s.top().second;
        s.pop();

        string co = (temp->color == 0) ? "BLACK" : "RED";
    
        for (int i = 0; i < depth; ++i) {
            cout << "-";
        }

        cout << "(" << co << ") " << temp->key.name << endl;

        if (temp->right)
        {
            s.push(make_pair(temp->right, depth + 1));
        }
        if (temp->left)
        {
            s.push(make_pair(temp->left, depth + 1));
        }
    }
}

void RB_tree::find_best_seller()
{

   float na_max = 0.0;
	publisher* na=new publisher;
	float eu_max = 0.0;
	publisher* eu=new publisher;
	float other_max = 0.0;
	publisher* other=new publisher;
	if (this->root == nullptr)
	{
		return;
	}
	stack<Node *> s;
	s.push(this->root);
	while (!s.empty())
	{
		Node *temp = s.top();
		s.pop();

		if (temp->key.eu_sales > eu_max)
		{
			eu_max = temp->key.eu_sales;
			*eu=temp->key;
		}
		if (temp->key.na_sales > na_max)
		{
			na_max = temp->key.na_sales;
			*na=temp->key;
		}
		if (temp->key.others_sales > other_max)
		{
			other_max = temp->key.others_sales;
			*other=temp->key;
		}

		if (temp->left)
		{
			s.push(temp->left);
		}
		if (temp->right)
		{
			s.push(temp->right);
		}
	}
	this->best_seller[0]=na;
	this->best_seller[1]=eu;
	this->best_seller[2]=other;
}

RB_tree::RB_tree()
{
    this->root = NULL;
    this->best_seller[0] = NULL;
    this->best_seller[1] = NULL;
    this->best_seller[2] = NULL;
}

RB_tree::~RB_tree()
{
    
}