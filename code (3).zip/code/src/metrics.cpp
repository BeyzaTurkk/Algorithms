#include "methods.h"

int getMax(std::vector<Item>& items, const std::string& attribute)
{

}

// min = age - ageWindow
// max = age + ageWindow
// rarityScore = (1 - probability) * (1 + item.age/ageMax)
void calculateRarityScores(std::vector<Item>& items, int ageWindow)
{

}
