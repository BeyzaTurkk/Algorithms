#include "methods.h"

std::vector<Item> readItemsFromFile(const std::string& filename) 
{

}

void writeItemsToFile(const std::string& filename, const std::vector<Item>& items) 
{

}
